
scoreboard players remove @s aj.tween_duration 1
execute if score @s aj.tween_duration matches 1.. run return 1
execute if score @s aj.tween_duration matches 0 on passengers run data modify entity @s interpolation_duration set value 1
execute if score @s aj.steve_attack_charge.frame matches -1 run function animated_java:mineraft/animations/steve_attack_charge/zzz/function_keyframe_loop_patch
data remove storage animated_java:temp args
execute store result storage animated_java:temp args.frame int 1 run scoreboard players get @s aj.steve_attack_charge.frame
function animated_java:mineraft/animations/steve_attack_charge/zzz/apply_frame with storage animated_java:temp args
execute if score @s aj.steve_attack_charge.frame matches 35.. run return run scoreboard players set @s aj.steve_attack_charge.frame -1
scoreboard players add @s aj.steve_attack_charge.frame 1