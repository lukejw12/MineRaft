$function $(hit_function)
