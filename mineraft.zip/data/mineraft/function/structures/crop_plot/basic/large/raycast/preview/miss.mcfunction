execute as @e[type=item_display,tag=mr.crop_plot_preview] if score @s mr.link = @p mr.link run kill @s

