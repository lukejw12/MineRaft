execute as @e[type=item_display,tag=mr.small_adv_crop_plot_preview] if score @s mr.link = #player_link mr.data run kill @s
kill @s