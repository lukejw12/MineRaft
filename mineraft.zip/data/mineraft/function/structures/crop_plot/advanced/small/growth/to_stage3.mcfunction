data modify entity @s data.state set value "stage3"
scoreboard players set @s mr.crop_plot_timer 0
function mineraft:structures/crop_plot/advanced/small/models/crop/update