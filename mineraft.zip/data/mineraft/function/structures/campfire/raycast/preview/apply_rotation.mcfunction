$data modify entity @s transformation.left_rotation set value $(rotation)
