execute if data storage mineraft:net {net_type:"simple_collection_net"} run data modify storage mineraft:net model set value "raft_structures:basic/collection_net"
execute if data storage mineraft:net {net_type:"advanced_collection_net"} run data modify storage mineraft:net model set value "raft_structures:basic/collection_net"
