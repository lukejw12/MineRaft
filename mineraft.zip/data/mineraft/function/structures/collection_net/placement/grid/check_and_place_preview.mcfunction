execute if entity @e[type=item_display,tag=mr.center,distance=..1] run return run execute as @e[type=item_display,tag=mr.net_preview] if score @s mr.link = #player_link mr.data run kill @s

execute as @e[type=item_display,tag=mr.net_preview] if score @s mr.link = #player_link mr.data run tp @s ~0.5 62 ~0.5
